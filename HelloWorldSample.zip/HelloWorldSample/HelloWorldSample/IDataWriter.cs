﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorldSample
{
    public interface IDataWriter
    {
        void WriteData(string dataToWrite);
    }
}

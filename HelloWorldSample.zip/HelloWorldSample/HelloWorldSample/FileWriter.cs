﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace HelloWorldSample
{
    public class FileWriter : IDataWriter
    {
        public void WriteData(string dataToWrite)
        {
            //Console.WriteLine(dataToWrite);
            string docpath = Directory.GetCurrentDirectory();

            // Append text to an existing file named "WriteLines.txt".
            using (StreamWriter outputFile = File.AppendText(docpath + @"\WriteFile.txt"))
            {
                outputFile.WriteLine(dataToWrite);
            }
        }
    }
}

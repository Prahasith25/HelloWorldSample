﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorldSample
{
    public class EventWriter : IDataWriter
    {
        public void WriteData(string dataToWrite)
        {
            //Write to Event Viewer here
        }
    }
}

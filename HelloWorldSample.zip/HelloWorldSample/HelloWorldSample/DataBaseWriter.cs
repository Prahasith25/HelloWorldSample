﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorldSample
{
    public class DataBaseWriter : IDataWriter
    {
        public void WriteData(string dataToWrite)
        {
            //Write to database here
        }
    }
}

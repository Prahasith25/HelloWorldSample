﻿using Microsoft.Extensions.Configuration;
using System;
using System.IO;

namespace HelloWorldSample
{
    class Program
    {
        static void Main(string[] args)
        {
            string dataToWrite = "Hello World!";

            var environmentName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);

            IConfigurationRoot configuration = builder.Build();

        
            DataWriterFactory factory = new DataWriterFactory();
            var writer = factory.CreateWriter(configuration["source"]);

            writer.WriteData(dataToWrite);
            Console.Read();


        }
    }
}
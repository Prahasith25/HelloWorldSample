﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorldSample
{
    public class DataWriterFactory
    {
        public IDataWriter CreateWriter(string type)
        {
            switch (type)
            {
                case "console": return new ConsoleWriter();
                case "database": return new DataBaseWriter();
                case "event": return new EventWriter();
                case "file": return new FileWriter();
                default: return new ConsoleWriter();
            }
        }
    }
}

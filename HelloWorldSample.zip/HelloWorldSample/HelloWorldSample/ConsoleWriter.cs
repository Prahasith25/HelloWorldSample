﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorldSample
{
    public class ConsoleWriter : IDataWriter
    {
        public void WriteData(string dataToWrite)
        {
            Console.WriteLine(dataToWrite);
        }
    }
}

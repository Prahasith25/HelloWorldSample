﻿using HelloWorldAPI.Controllers;
using HelloWorldAPI.Services;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using Moq;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;

namespace HelloWorldAPITests
{
    public class CalcControllerTests
    {
        [Fact]
        public async void CalcController_GetAdditionAsync_200_response()
        {
            // Arrange
            Mock<ICalculatorService> service = new Mock<ICalculatorService>();

            service
                .Setup(s => s.Add(It.IsAny<int>(), It.IsAny<int>()))
                .ReturnsAsync(8);

            CalcController ctr = new CalcController(service.Object);

            // Act
            var result = await ctr.GetAdditionAsync(3,5);

            // Assert
            var actualObj = result.Should().BeOfType<OkObjectResult>().Subject;

            var expectedObj = new OkObjectResult(8);

            actualObj.StatusCode.Should().Be(expectedObj.StatusCode);
            actualObj.Value.Should().Be(8);
        }

        [Fact]
        public async void CalcController_GetMultiplicationAsyncc_200_response()
        {
            // Arrange
            Mock<ICalculatorService> service = new Mock<ICalculatorService>();

            service
                .Setup(s => s.Multiply(It.IsAny<int>(), It.IsAny<int>()))
                .ReturnsAsync(15);

            CalcController ctr = new CalcController(service.Object);

            // Act
            var result = await ctr.GetMultiplicationAsync(3, 5);

            // Assert
            var actualObj = result.Should().BeOfType<OkObjectResult>().Subject;

            var expectedObj = new OkObjectResult(15);

            actualObj.StatusCode.Should().Be(expectedObj.StatusCode);
            actualObj.Value.Should().Be(15);
        }

        [Fact]
        public async void CalcController_GetDivisionAsync_200_response()
        {
            // Arrange
            Mock<ICalculatorService> service = new Mock<ICalculatorService>();

            service
                .Setup(s => s.Devide(It.IsAny<int>(), It.IsAny<int>()))
                .ReturnsAsync(5);

            CalcController ctr = new CalcController(service.Object);

            // Act
            var result = await ctr.GetDivisionAsync(15, 3);

            // Assert
            var actualObj = result.Should().BeOfType<OkObjectResult>().Subject;

            var expectedObj = new OkObjectResult(5);

            actualObj.StatusCode.Should().Be(expectedObj.StatusCode);
            actualObj.Value.Should().Be(5);
        }

        [Fact]
        public async void CalcController_GetSubtractionAsync_200_response()
        {
            // Arrange
            Mock<ICalculatorService> service = new Mock<ICalculatorService>();

            service
                .Setup(s => s.Remove(It.IsAny<int>(), It.IsAny<int>()))
                .ReturnsAsync(5);

            CalcController ctr = new CalcController(service.Object);

            // Act
            var result = await ctr.GetSubtractionAsync(10, 5);

            // Assert
            var actualObj = result.Should().BeOfType<OkObjectResult>().Subject;

            var expectedObj = new OkObjectResult(5);

            actualObj.StatusCode.Should().Be(expectedObj.StatusCode);
            actualObj.Value.Should().Be(5);
        }
    }
}

﻿using HelloWorldAPI.Services;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace HelloWorldAPITests
{
    public class CalculatorServiceTests
    {
        [Fact]
        public async void CalculatorService_Add()
        {
            // Arrange
            CalculatorService service = new CalculatorService();
            var result = await service.Add(1, 2);
            Assert.Equal(result, 3);
        }

        [Fact]
        public async void CalculatorService_Devide()
        {
            // Arrange
            CalculatorService service = new CalculatorService();
            var result = await service.Devide(50, 10);
            Assert.Equal(result, 5);
        }

        [Fact]
        public async void CalculatorService_Subtract()
        {
            // Arrange
            CalculatorService service = new CalculatorService();
            var result = await service.Remove(5, 1);
            Assert.Equal(result, 4);
        }

        [Fact]
        public async void CalculatorService_Multiply()
        {
            // Arrange
            CalculatorService service = new CalculatorService();
            var result = await service.Multiply(10, 3);
            Assert.Equal(result, 30);
        }
    }
}

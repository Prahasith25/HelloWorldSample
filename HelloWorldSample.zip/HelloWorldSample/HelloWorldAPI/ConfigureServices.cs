﻿using HelloWorldAPI.Services;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HelloWorldAPI
{

    public static class ConfigureServices
    {
        public static IServiceCollection ConfigureHelloWorldSampleServices(this IServiceCollection collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException(nameof(collection));
            }

            // Add your services here in the collection
            collection
                .AddScoped<ICalculatorService, CalculatorService>();

            return collection;
        }
    }
}

﻿using HelloWorldAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HelloWorldAPI.Controllers
{
    [Produces("application/json")]
    [Route("[controller]")]
    public class CalcController : Controller
    {
        private readonly ICalculatorService _calculatorService;
        public CalcController(ICalculatorService calculatorService)
        {
            _calculatorService = calculatorService;
        }
       
   
        [HttpGet("add")]
        public async Task<IActionResult> GetAdditionAsync(int first, int second)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new
                {
                    error = true,
                    errorDetails = new
                    {
                        code = "InvalidModel",
                        description = "Please Fill All mmandatory values"
                    }
                });
            }

            var result = await _calculatorService.Add(first, second);
            return Ok(result);
        }

        [HttpGet("multiply")]
        public async Task<IActionResult> GetMultiplicationAsync(int first, int second)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new
                {
                    error = true,
                    errorDetails = new
                    {
                        code = "InvalidModel",
                        description = "Please Fill All mmandatory values"
                    }
                });
            }

            var result = await _calculatorService.Multiply(first, second);
            return Ok(result);
        }


        [HttpGet("devide")]
        public async Task<IActionResult> GetDivisionAsync(int first, int second)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new
                {
                    error = true,
                    errorDetails = new
                    {
                        code = "InvalidModel",
                        description = "Please Fill All mmandatory values"
                    }
                });
            }

            var result = await _calculatorService.Devide(first, second);
            return Ok(result);
        }

        [HttpGet("minus")]
        public async Task<IActionResult> GetSubtractionAsync(int first, int second)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new
                {
                    error = true,
                    errorDetails = new
                    {
                        code = "InvalidModel",
                        description = "Please Fill All mmandatory values"
                    }
                });
            }

            var result = await _calculatorService.Remove(first, second);
            return Ok(result);
        }
    }
}

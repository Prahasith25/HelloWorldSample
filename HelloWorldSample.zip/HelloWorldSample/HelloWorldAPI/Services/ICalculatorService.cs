﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HelloWorldAPI.Services
{
    public interface ICalculatorService
    {
        Task<int> Add(int first, int second);

        Task<int> Remove(int first, int second);

        Task<int> Devide(int first, int second);

        Task<int> Multiply(int first, int second);
    }
}

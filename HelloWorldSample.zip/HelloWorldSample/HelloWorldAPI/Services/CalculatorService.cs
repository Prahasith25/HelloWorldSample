﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HelloWorldAPI.Services
{
    public class CalculatorService : ICalculatorService
    {
        public async Task<int> Add(int first, int second)
        {
            return await Task.FromResult(first + second);
        }

        public async Task<int> Devide(int first, int second)
        {
            return await Task.FromResult(first / second);
        }

        public async Task<int> Multiply(int first, int second)
        {
            return await Task.FromResult(first * second);
        }

        public async Task<int> Remove(int first, int second)
        {
            return await Task.FromResult(first - second);
        }
    }
}
